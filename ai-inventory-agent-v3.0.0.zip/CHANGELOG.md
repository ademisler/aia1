# Changelog

## 3.0.0 - Fresh Rewrite
- Full clean rewrite from scratch with new architecture
- Minimal, robust core (autoloading, hooks, REST, admin UI)
- Professional unified styling and templates
- Placeholder implementations for AI and data layers (to be extended)